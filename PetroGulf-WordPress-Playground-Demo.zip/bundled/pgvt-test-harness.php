<?php
/**
 * TEST HARNESS ONLY. Never deploy to a real site.
 *
 * Stands in for the VesselFinder API (whose host the test bed cannot reach) by answering
 * WordPress's outbound HTTP call with responses shaped like the documented Vessels method,
 * counts every supplier call, and captures outgoing email.
 */

defined( 'ABSPATH' ) || exit;

add_filter(
	'pre_http_request',
	static function ( $pre, $args, $url ) {
		if ( 'api.vesselfinder.com' !== wp_parse_url( $url, PHP_URL_HOST ) ) {
			return $pre;
		}
		parse_str( (string) wp_parse_url( $url, PHP_URL_QUERY ), $q );
		$state              = get_option( 'pgvt_test_http', array( 'calls' => 0 ) );
		$state['calls']     = (int) $state['calls'] + 1;
		$state['last_args'] = $q;
		$state['last_ua']   = isset( $args['user-agent'] ) ? $args['user-agent'] : '';
		update_option( 'pgvt_test_http', $state, false );

		$imo  = isset( $q['imo'] ) ? (string) $q['imo'] : '';
		$want = isset( $q['extradata'] ) ? explode( ',', (string) $q['extradata'] ) : array();
		$now  = time();

		if ( '9074729' === $imo ) {
			return new WP_Error( 'http_request_failed', 'cURL error 28: Operation timed out after 8001 milliseconds' );
		}
		$reply = static function ( $body, $code = 200 ) {
			return array(
				'headers'  => array( 'content-type' => 'application/json' ),
				'body'     => wp_json_encode( $body ),
				'response' => array( 'code' => $code, 'message' => 'OK' ),
				'cookies'  => array(),
				'filename' => null,
			);
		};
		if ( '9500003' === $imo ) {
			return $reply( array( 'error' => 'Not enough credits' ) );
		}
		if ( '1234567' === $imo ) {
			return $reply( array() );
		}

		if ( '9987768' === $imo ) {
			// Identity and particulars as published for MINTAKA; position and voyage are illustrative.
			$vessel = array(
				'AIS' => array(
					'MMSI'        => 319297200,
					'TIMESTAMP'   => gmdate( 'Y-m-d H:i:s', $now - 38 * 60 ) . ' UTC',
					'LATITUDE'    => -17.85,
					'LONGITUDE'   => 41.2,
					'COURSE'      => 205,
					'SPEED'       => 12.4,
					'HEADING'     => 204,
					'NAVSTAT'     => 0,
					'IMO'         => 9987768,
					'NAME'        => 'MINTAKA',
					'CALLSIGN'    => 'ZGRX9',
					'TYPE'        => 80,
					'A'           => 150,
					'B'           => 33,
					'C'           => 16,
					'D'           => 16,
					'DRAUGHT'     => 11.5,
					'DESTINATION' => 'DURBAN',
					'LOCODE'      => 'ZADUR',
					'ETA_AIS'     => gmdate( 'm-d H:i', $now + 3 * DAY_IN_SECONDS ),
					'ETA'         => gmdate( 'Y-m-d H:00:00', $now + 3 * DAY_IN_SECONDS ),
					'SRC'         => ! empty( $q['sat'] ) ? 'SAT' : 'TER',
					'ZONE'        => 'Indian Ocean',
					'ECA'         => false,
				),
			);
		} elseif ( '9321483' === $imo ) {
			$vessel = array(
				'AIS' => array(
					'MMSI'        => 636000001,
					'TIMESTAMP'   => gmdate( 'Y-m-d H:i:s', $now - 3 * DAY_IN_SECONDS ) . ' UTC',
					'LATITUDE'    => -33.9,
					'LONGITUDE'   => 18.4,
					'COURSE'      => 360,
					'SPEED'       => 0,
					'HEADING'     => 511,
					'NAVSTAT'     => 5,
					'IMO'         => 9321483,
					'NAME'        => 'TEST STALE VESSEL',
					'TYPE'        => 70,
					'DRAUGHT'     => 0,
					'DESTINATION' => '',
					'SRC'         => 'TER',
				),
			);
		} else {
			return $reply( array() );
		}

		if ( in_array( 'voyage', $want, true ) ) {
			$vessel['VOYAGE'] = array(
				'LOCODE'      => null,
				'DEPARTURE'   => gmdate( 'Y-m-d H:i:s', $now - 12 * DAY_IN_SECONDS ) . ' UTC',
				'LASTPORT'    => '9987768' === $imo ? 'SIKKA' : 'CAPE TOWN',
				'LASTCOUNTRY' => '9987768' === $imo ? 'India' : 'South Africa',
			);
		}
		if ( in_array( 'master', $want, true ) && '9987768' === $imo ) {
			$vessel['MASTERDATA'] = array(
				'IMO'     => 9987768,
				'NAME'    => 'MINTAKA',
				'FLAG'    => 'Cayman Islands',
				'TYPE'    => 'Chemical/Oil Products Tanker',
				'BUILT'   => 2024,
				'LENGTH'  => 183,
				'BEAM'    => 32.2,
				'GT'      => 29438,
				'DWT'     => 49818,
			);
		}
		return $reply( array( $vessel ) );
	},
	10,
	3
);

// Capture email instead of sending it.
add_filter(
	'pre_wp_mail',
	static function ( $short, $atts ) {
		update_option( 'pgvt_test_mail', $atts, false );
		return true;
	},
	10,
	2
);

// Test-controlled limits.
add_filter( 'pgvt_config_daily_lookup_cap', static function ( $v ) {
	$o = get_option( 'pgvt_test_daily_cap' );
	return false === $o ? $v : (int) $o;
} );
add_filter( 'pgvt_config_rate_limit_per_hour', static function ( $v ) {
	$o = get_option( 'pgvt_test_rate_limit' );
	return false === $o ? $v : (int) $o;
} );

// Test-only endpoints to inspect and reset state.
add_action(
	'rest_api_init',
	static function () {
		register_rest_route(
			'pgvt-test/v1',
			'/state',
			array(
				'methods'             => 'GET',
				'permission_callback' => '__return_true',
				'callback'            => static function () {
					return array(
						'http'  => get_option( 'pgvt_test_http', array( 'calls' => 0 ) ),
						'mail'  => get_option( 'pgvt_test_mail', null ),
						'usage' => get_option( 'pgvt_usage', null ),
						'log'   => array_slice( (array) get_option( 'pgvt_log', array() ), 0, 5 ),
					);
				},
			)
		);
		register_rest_route(
			'pgvt-test/v1',
			'/reset',
			array(
				'methods'             => 'POST',
				'permission_callback' => '__return_true',
				'callback'            => static function ( WP_REST_Request $r ) {
					global $wpdb;
					$wpdb->query( "DELETE FROM {$wpdb->options} WHERE option_name LIKE '\_transient\_pgvt\_%' OR option_name LIKE '\_transient\_timeout\_pgvt\_%'" );
					foreach ( array( 'pgvt_test_http', 'pgvt_test_mail', 'pgvt_usage', 'pgvt_log', 'pgvt_test_daily_cap', 'pgvt_test_rate_limit' ) as $o ) {
						delete_option( $o );
					}
					if ( null !== $r->get_param( 'daily_cap' ) ) {
						update_option( 'pgvt_test_daily_cap', (int) $r->get_param( 'daily_cap' ), false );
					}
					if ( null !== $r->get_param( 'rate_limit' ) ) {
						update_option( 'pgvt_test_rate_limit', (int) $r->get_param( 'rate_limit' ), false );
					}
					if ( $r->get_param( 'expire_position' ) ) {
						$wpdb->query( "DELETE FROM {$wpdb->options} WHERE option_name LIKE '\_transient\_pgvt\_v\_%' OR option_name LIKE '\_transient\_timeout\_pgvt\_v\_%'" );
					}
					wp_cache_flush();
					return array( 'reset' => true );
				},
			)
		);
		register_rest_route(
			'pgvt-test/v1',
			'/expire-position',
			array(
				'methods'             => 'POST',
				'permission_callback' => '__return_true',
				'callback'            => static function () {
					global $wpdb;
					$wpdb->query( "DELETE FROM {$wpdb->options} WHERE option_name LIKE '\_transient\_pgvt\_v\_%' OR option_name LIKE '\_transient\_timeout\_pgvt\_v\_%'" );
					wp_cache_flush();
					return array( 'expired' => true );
				},
			)
		);
	}
);
