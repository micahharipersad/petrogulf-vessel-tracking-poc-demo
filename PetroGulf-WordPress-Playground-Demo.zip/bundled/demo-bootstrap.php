<?php
// Demo-only settings. All AIS provider responses are intercepted by the test harness.
if ( ! defined( 'PGVT_PROVIDER' ) ) define( 'PGVT_PROVIDER', 'vesselfinder' );
if ( ! defined( 'PGVT_VESSELFINDER_API_KEY' ) ) define( 'PGVT_VESSELFINDER_API_KEY', 'DEMO-KEY-NOT-REAL' );
if ( ! defined( 'PGVT_ENQUIRY_RECIPIENT' ) ) define( 'PGVT_ENQUIRY_RECIPIENT', 'demo@example.invalid' );
if ( ! defined( 'PGVT_USE_SATELLITE' ) ) define( 'PGVT_USE_SATELLITE', false );
require_once __DIR__ . '/pgvt-test-harness.php';
